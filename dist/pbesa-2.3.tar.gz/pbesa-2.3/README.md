# PBESA v2.3
An artificial intelligence platform for the implementation of multi-agent systems based on python 3 and the BESA model

