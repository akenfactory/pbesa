from enum import Enum
class PoolType(Enum):
    BLOCK = 1
    NO_BLOCK = 2
