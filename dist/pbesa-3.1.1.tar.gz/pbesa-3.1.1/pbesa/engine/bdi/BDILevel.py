from enum import Enum

class BDILevel(Enum):

	PHYSIOLOGY = 5
	SAFETY = 4
	SOCIAL = 3
	ESTEEM = 2
	SELF_REALIZATION = 1
		