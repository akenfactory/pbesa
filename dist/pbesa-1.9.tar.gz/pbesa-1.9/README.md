# PBESA v1.0
An artificial intelligence platform for the implementation of multi-agent systems based on python 3 and the BESA model

